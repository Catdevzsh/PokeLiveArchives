public class Client {
    public static void main(String[] args) {
        // TODO: Implement client functionality
    }
}