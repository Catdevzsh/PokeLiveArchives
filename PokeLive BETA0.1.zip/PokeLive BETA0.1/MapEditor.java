public class MapEditor {
    public static void main(String[] args) {
        // TODO: Create a simple map editor
    }
}