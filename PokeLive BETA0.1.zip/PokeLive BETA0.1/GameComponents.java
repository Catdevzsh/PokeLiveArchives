public class GameComponents {
    public static void main(String[] args) {
        // TODO: Implement game components
    }
}