public class Server {
    public static void main(String[] args) {
        // TODO: Implement server functionality
    }
}