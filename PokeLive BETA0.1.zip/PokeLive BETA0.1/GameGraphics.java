public class GameGraphics {
    public static void main(String[] args) {
        // TODO: Implement game graphics
    }
}