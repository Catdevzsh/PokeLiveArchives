public class GameSound {
    public static void main(String[] args) {
        // TODO: Implement game sound
    }
}