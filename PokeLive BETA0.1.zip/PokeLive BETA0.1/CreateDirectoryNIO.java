import java.nio.file.*;

public class CreateDirectoryNIO {
    public static void main(String[] args) {
        try {
            Path path = Paths.get("TEST_MMO_X.X.X.X.1.0");
            Files.createDirectories(path);
            System.out.println("Directory created");
        } catch (Exception e) {
            System.out.println("Failed to create directory");
        }
    }
}