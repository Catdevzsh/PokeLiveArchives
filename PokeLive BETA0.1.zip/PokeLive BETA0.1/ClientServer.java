import java.net.*;
import java.io.*;

public class ClientServer {
    @SuppressWarnings("resource")
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(8000);
            Socket socket = serverSocket.accept();
            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            // Handle client-server communication
            String inputLine;
            while ((inputLine = in.readUTF()) != null) {
                out.writeUTF("Server: " + inputLine);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}