import java.io.File;

public class CreateDirectory {
    public static void main(String[] args) {
        File dir = new File("TEST_MMO_X.X.X.X.1.0");
        dir.mkdirs();
    }
}