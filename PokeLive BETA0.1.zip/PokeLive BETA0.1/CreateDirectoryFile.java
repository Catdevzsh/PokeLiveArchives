import java.io.File;

public class CreateDirectoryFile {
    public static void main(String[] args) {
        try {
            File directory = new File("TEST_MMO_X.X.X.X.1.0");
            if (!directory.exists()) {
                directory.mkdir();
                System.out.println("Directory created");
            } else {
                System.out.println("Directory already exists");
            }
        } catch (Exception e) {
            System.out.println("Failed to create directory");
        }
    }
}